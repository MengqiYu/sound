#include <stdio.h>
#include "ourheader.h"

int main(void){
	printf("Main function\n");
	foo();
}
